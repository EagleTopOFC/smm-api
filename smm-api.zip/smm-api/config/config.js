module.exports = {
  databaseUrl: 'mongodb://localhost/smm-api', // URL de la base de datos
  jwtSecret: 'your-jwt-secret', // Clave secreta de JWT
  apiKeySecret: 'your-api-key-secret', // Clave secreta de API Key
};
